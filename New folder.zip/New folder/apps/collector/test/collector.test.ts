import { describe, expect, it } from 'vitest';

import worker from '../src/index';

import {
  contractFixtures,
} from '../../../packages/contract/fixtures/payloads';

const PUBLIC_KEY =
  'tw_pub_12345678901234567890123456789012';

const site = {
  id: 123,

  publicKey: PUBLIC_KEY,

  allowedHosts: [
    'example.com',
    'www.example.com',
    '*.example.com',
  ],

  live: true,

  region: 'in' as const,

  identitySecret:
    'stage2-test-secret',
};

function env(
  overrides: Partial<
    Record<string, unknown>
  > = {},
) {
  const sent: unknown[] = [];

  let limited = false;

  return {
    sent,

    env: {
      SITE_CONFIG: {
        async get(key: string) {
          if (
            key ===
            `site:${PUBLIC_KEY}`
          ) {
            return JSON.stringify(site);
          }

          return null;
        },
      },

      EVENTS: {
        async send(message: unknown) {
          sent.push(message);
        },
      },

      RATE_LIMITER: {
        async limit() {
          return {
            success: !limited,
          };
        },
      },

      ...overrides,
    },

    setLimited(value: boolean) {
      limited = value;
    },
  };
}

function context() {
  const promises: Promise<unknown>[] = [];

  return {
    promises,

    waitUntil(
      promise: Promise<unknown>,
    ) {
      promises.push(promise);
    },
  };
}

function validBody(
  extra: Record<string, unknown> = {},
) {
  return JSON.stringify({
    s: PUBLIC_KEY,

    n: 'pageview',

    u: 'https://example.com/',

    q: 1,

    t: Date.now(),

    v: 1,

    ...extra,
  });
}

describe(
  'Stage 2 collector',
  () => {
    it(
      'keeps /health working',
      async () => {
        const h = env();

        const res =
          await worker.fetch(
            new Request(
              'https://in.tailwatch.com/health',
            ),
            h.env,
            context(),
          );

        expect(res.status).toBe(200);

        expect(
          await res.text(),
        ).toBe('ok');

        expect(
          res.headers.get(
            'x-tw-contract',
          ),
        ).toBeTruthy();
      },
    );

    it(
      'accepts a valid POST and enqueues the event',
      async () => {
        const h = env();

        const ctx = context();

        const res =
          await worker.fetch(
            new Request(
              'https://in.tailwatch.com/e',
              {
                method: 'POST',

                headers: {
                  'content-type':
                    'application/json',

                  'cf-connecting-ip':
                    '203.0.113.7',

                  'user-agent':
                    'Mozilla/5.0',
                },

                body: validBody(),
              },
            ),
            h.env,
            ctx,
          );

        expect(res.status).toBe(204);

        await Promise.all(
          ctx.promises,
        );

        expect(h.sent).toHaveLength(1);

        const message =
          h.sent[0] as any;

        expect(message.v).toBe(1);

        expect(message.type).toBe(
          'event',
        );

        expect(
          message.visitor.hash,
        ).toEqual(expect.any(String));

        expect(
          message.visitor.prevHash,
        ).toEqual(expect.any(String));
      },
    );

    it(
      'rejects malformed JSON',
      async () => {
        const h = env();

        const res =
          await worker.fetch(
            new Request(
              'https://in.tailwatch.com/e',
              {
                method: 'POST',

                headers: {
                  'content-type':
                    'application/json',
                },

                body: '{bad json',
              },
            ),
            h.env,
            context(),
          );

        expect(res.status).toBe(400);

        expect(h.sent).toHaveLength(0);
      },
    );

    it(
      'rejects an oversized request',
      async () => {
        const h = env();

        const body =
          'x'.repeat(33 * 1024);

        const res =
          await worker.fetch(
            new Request(
              'https://in.tailwatch.com/e',
              {
                method: 'POST',

                headers: {
                  'content-type':
                    'application/json',

                  'content-length':
                    String(
                      body.length,
                    ),
                },

                body,
              },
            ),
            h.env,
            context(),
          );

        expect(res.status).toBe(413);

        expect(h.sent).toHaveLength(0);
      },
    );

    it(
      'drops an unknown site',
      async () => {
        const h = env();

        const body =
          validBody({
            s: 'tw_pub_unknown',
          });

        const res =
          await worker.fetch(
            new Request(
              'https://in.tailwatch.com/e',
              {
                method: 'POST',

                headers: {
                  'content-type':
                    'application/json',

                  'cf-connecting-ip':
                    '203.0.113.7',
                },

                body,
              },
            ),
            h.env,
            context(),
          );

        expect(res.status).toBe(204);

        expect(
          res.headers.get(
            'x-tw-dropped',
          ),
        ).toBe('not_found');

        expect(h.sent).toHaveLength(0);
      },
    );

    it(
      'drops a hostname mismatch',
      async () => {
        const h = env();

        const body =
          validBody({
            u: 'https://evil.example/',
          });

        const res =
          await worker.fetch(
            new Request(
              'https://in.tailwatch.com/e',
              {
                method: 'POST',

                headers: {
                  'content-type':
                    'application/json',

                  'cf-connecting-ip':
                    '203.0.113.7',
                },

                body,
              },
            ),
            h.env,
            context(),
          );

        expect(res.status).toBe(204);

        expect(
          res.headers.get(
            'x-tw-dropped',
          ),
        ).toBe('hostname');

        expect(h.sent).toHaveLength(0);
      },
    );

    it(
      'drops an obvious bot',
      async () => {
        const h = env();

        const res =
          await worker.fetch(
            new Request(
              'https://in.tailwatch.com/e',
              {
                method: 'POST',

                headers: {
                  'content-type':
                    'application/json',

                  'cf-connecting-ip':
                    '203.0.113.7',

                  'user-agent':
                    'Googlebot/2.1',
                },

                body: validBody(),
              },
            ),
            h.env,
            context(),
          );

        expect(res.status).toBe(204);

        expect(
          res.headers.get(
            'x-tw-dropped',
          ),
        ).toBe('bot');

        expect(h.sent).toHaveLength(0);
      },
    );

    it(
      'drops when GPC is enabled',
      async () => {
        const h = env();

        const res =
          await worker.fetch(
            new Request(
              'https://in.tailwatch.com/e',
              {
                method: 'POST',

                headers: {
                  'content-type':
                    'application/json',

                  'cf-connecting-ip':
                    '203.0.113.7',

                  'user-agent':
                    'Mozilla/5.0',

                  'Sec-GPC': '1',
                },

                body: validBody(),
              },
            ),
            h.env,
            context(),
          );

        expect(res.status).toBe(204);

        expect(
          res.headers.get(
            'x-tw-dropped',
          ),
        ).toBe('gpc');

        expect(h.sent).toHaveLength(0);
      },
    );

    it(
      'returns 429 when rate limited',
      async () => {
        const h = env();

        h.setLimited(true);

        const res =
          await worker.fetch(
            new Request(
              'https://in.tailwatch.com/e',
              {
                method: 'POST',

                headers: {
                  'content-type':
                    'application/json',
                },

                body: validBody(),
              },
            ),
            h.env,
            context(),
          );

        expect(res.status).toBe(429);

        expect(
          res.headers.get(
            'retry-after',
          ),
        ).toBe('10');

        expect(h.sent).toHaveLength(0);
      },
    );

    it(
      'answers OPTIONS',
      async () => {
        const h = env();

        const res =
          await worker.fetch(
            new Request(
              'https://in.tailwatch.com/e',
              {
                method: 'OPTIONS',
              },
            ),
            h.env,
            context(),
          );

        expect(res.status).toBe(204);

        expect(
          res.headers.get(
            'access-control-allow-origin',
          ),
        ).toBe('*');
      },
    );

    it(
      'fails closed when identitySecret is missing',
      async () => {
        const h = env({
          SITE_CONFIG: {
            async get() {
              return JSON.stringify({
                ...site,

                identitySecret:
                  undefined,
              });
            },
          },
        });

        const res =
          await worker.fetch(
            new Request(
              'https://in.tailwatch.com/e',
              {
                method: 'POST',

                headers: {
                  'content-type':
                    'application/json',

                  'cf-connecting-ip':
                    '203.0.113.7',

                  'user-agent':
                    'Mozilla/5.0',
                },

                body: validBody(),
              },
            ),
            h.env,
            context(),
          );

        expect(res.status).toBe(204);

        expect(
          res.headers.get(
            'x-tw-dropped',
          ),
        ).toBe(
          'identity_unavailable',
        );

        expect(h.sent).toHaveLength(0);
      },
    );

    it(
      'replays the Stage 1 fixture corpus',
      async () => {
        const h = env();

        for (
          const fixture
          of contractFixtures
        ) {
          const ctx = context();

          const res =
            await worker.fetch(
              new Request(
                'https://in.tailwatch.com/e',
                {
                  method: 'POST',

                  headers: {
                    'content-type':
                      'application/json',

                    'cf-connecting-ip':
                      '203.0.113.7',

                    'user-agent':
                      'Mozilla/5.0',
                  },

                  body:
                    JSON.stringify(
                      fixture.payload,
                    ),
                },
              ),
              h.env,
              ctx,
            );

          expect(
            [200, 204, 400, 413, 429],
          ).toContain(
            res.status,
          );
        }
      },
    );

    it(
      'serves the tracking pixel and enqueues its event',
      async () => {
        const h = env();

        const ctx = context();

        const url =
          new URL(
            'https://in.tailwatch.com/e.gif',
          );

        url.searchParams.set(
          's',
          PUBLIC_KEY,
        );

        url.searchParams.set(
          'n',
          'pageview',
        );

        url.searchParams.set(
          'u',
          'https://example.com/',
        );

        url.searchParams.set(
          'q',
          '1',
        );

        url.searchParams.set(
          't',
          String(Date.now()),
        );

        url.searchParams.set(
          'v',
          '1',
        );

        const req =
          new Request(url, {
            method: 'GET',

            headers: {
              'cf-connecting-ip':
                '203.0.113.7',

              'user-agent':
                'Mozilla/5.0',
            },
          });

        const res =
          await worker.fetch(
            req,
            h.env,
            ctx,
          );

        expect(res.status).toBe(200);

        expect(
          res.headers.get(
            'content-type',
          ),
        ).toBe('image/gif');

        expect(
          res.headers.get(
            'cache-control',
          ),
        ).toBe('no-store');

        await Promise.all(
          ctx.promises,
        );

        expect(h.sent).toHaveLength(1);
      },
    );
  },
);